// Generated automatically. Don't edit manually!

#define ASN_DISABLE_OER_SUPPORT 1

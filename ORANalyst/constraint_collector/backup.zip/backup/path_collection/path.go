package path_collection

import (
	"fmt"
	"go/types"
	"go_fsmbuilder/PdgGraph"
	"strings"

	"golang.org/x/tools/go/packages"
	"golang.org/x/tools/go/ssa"
)

type PathExplorer struct {
	callPaths    map[*PdgGraph.Function][][]*PdgGraph.Block
	callConds    map[*PdgGraph.Function][][]string
	exploreFuncs map[*PdgGraph.Function]bool
	moduleName   string
	typeTracker  *typeTracker
}

type edge struct {
	from *PdgGraph.Block
	to   *PdgGraph.Block
}

func NewPathExplorer(module string, trackedType types.Type,
	exploreFuncs map[*PdgGraph.Function]bool, typePkg packages.Package) *PathExplorer {
	if exploreFuncs == nil {
		exploreFuncs = make(map[*PdgGraph.Function]bool)
	}
	return &PathExplorer{
		callPaths:    make(map[*PdgGraph.Function][][]*PdgGraph.Block),
		callConds:    make(map[*PdgGraph.Function][][]string),
		exploreFuncs: make(map[*PdgGraph.Function]bool),
		moduleName:   module,
		typeTracker:  NewTypeTracker(trackedType, typePkg),
	}
}

// trimErrorPaths for function that returns errors,
// trim the paths that return errors instead of nil
// known issue: will fail if error is directly forwarded from another function
// as in that case no error is not represented by a const nil-pointer
// can add a dataflow analysis to fix this
func trimErrorPaths(f *PdgGraph.Function, paths [][]*PdgGraph.Block,
	conds [][]string) ([][]*PdgGraph.Block, [][]string) {
	resPaths := make([][]*PdgGraph.Block, 0)
	resConds := make([][]string, 0)

	// find out which return type is error
	// currently only support one error situation
	if f.SsaFuncPointer == nil {
		return paths, conds
	}

	signature := f.SsaFuncPointer.Signature
	if signature == nil {
		return paths, conds
	}

	results := signature.Results()
	if results == nil {
		return paths, conds
	}

	errorIdx := -1
	errorType := types.Universe.Lookup("error").Type()
	for i := 0; i < results.Len(); i++ {
		if results.At(i).Type() == errorType {
			errorIdx = i
			break
		}
	}
	if errorIdx == -1 {
		return paths, conds
	}

	for i, p := range paths {
		lastBlock := p[len(p)-1]
		lastInstr := lastBlock.LastInstr
		retInstr, ok := (*lastInstr.SsaInstrPtr).(*ssa.Return)
		if !ok {
			panic(fmt.Sprintf("last instruction is not return: %v\n", lastInstr.Text))
		}
		if constVal, ok := retInstr.Results[errorIdx].(*ssa.Const); ok {
			if constVal.IsNil() {
				resPaths = append(resPaths, p)
				resConds = append(resConds, conds[i])
			}
		}
	}

	return resPaths, resConds
}

// MarkErrorBlock Given a function, mark the blocks that only lead to error
func (pe *PathExplorer) MarkErrorBlock(f *PdgGraph.Function) map[*PdgGraph.Block]bool {
	res := make(map[*PdgGraph.Block]bool)
	if f.SsaFuncPointer == nil {
		return res
	}

	signature := f.SsaFuncPointer.Signature
	if signature == nil {
		return res
	}

	results := signature.Results()
	if results == nil {
		return res
	}

	errorIdx := -1
	errorType := types.Universe.Lookup("error").Type()
	for i := 0; i < results.Len(); i++ {
		if results.At(i).Type() == errorType {
			errorIdx = i
			break
		}
	}
	if errorIdx == -1 {
		return res
	}

	for _, b := range f.ContainsBlock {
		if b.LastInstr == nil {
			continue
		}
		// find blocks that only return error
		if retInstr, ok := (*b.LastInstr.SsaInstrPtr).(*ssa.Return); ok {
			if constVal, ok := retInstr.Results[errorIdx].(*ssa.Const); ok && constVal.IsNil() {
				// fmt.Printf("non-error block: %v %v, last instruction: %v\n", b.Function.Name, b.Id, b.LastInstr.Text)
				res[b] = false
			} else {
				isErrorBlock := false
				retVar := retInstr.Results[errorIdx]
				fmt.Printf("retVar: %v\n", retVar.Name())
				fmt.Printf("error block: %v %v, last instruction: %v\n", b.Function.Name, b.Id, b.LastInstr.Text)
				instr := b.LastInstr
				for {
					if instr == nil {
						break
					}
					if call, ok := (*instr.SsaInstrPtr).(*ssa.Call); ok && call == retVar {
						fmt.Printf("call: %v\n", call.String())
						switch v := call.Common().Value.(type) {
						case *ssa.Builtin:
							if v.Name() == "panic" {
								isErrorBlock = true
							}
						case *ssa.Function:
							fullName := v.String()

							if fullName == "errors.New" || fullName == "fmt.Errorf" {
								isErrorBlock = true
							}

							if strings.Contains(fullName, "errors.New") {
								isErrorBlock = true
							}
						}

					}
					instr = instr.InstrPrev
				}
				fmt.Printf("isErrorBlock: %v\n", isErrorBlock)
				res[b] = isErrorBlock
			}
		}
	}

	l := len(res)
	// chaotic iterate all blocks to find the ones that lead to error blocks
	//  until no new blocks are found
	for {
		if l == len(res) {
			break
		}

		for _, b := range f.ContainsBlock {
			if b.LastInstr == nil {
				continue
			}
			if _, ok := res[b]; ok {
				continue
			}
			blockRes := true
			for _, succ := range b.Successors {
				if !res[succ] {
					blockRes = false
				}
			}
			if blockRes {
				res[b] = true
			}
		}
	}
	return res
}

// FindPaths context-insentive function-wise exploration.
func (pe *PathExplorer) FindPaths(progInfo *PdgGraph.ProgramInfo,
	entry *PdgGraph.Function) (allPaths [][]*PdgGraph.Block, allPathsConds [][]string) {
	type pathState struct {
		curFunc       *PdgGraph.Function
		curBlock      *PdgGraph.Block
		prevBlock     *PdgGraph.Block
		path          []*PdgGraph.Block
		conds         []string
		visitedBlocks map[edge]bool
	}

	pathStack := []pathState{
		{
			curFunc:       entry,
			curBlock:      entry.FirstBlock,
			prevBlock:     nil,
			path:          make([]*PdgGraph.Block, 0),
			conds:         make([]string, 0),
			visitedBlocks: make(map[edge]bool),
		},
	}

	errorBlocks := pe.MarkErrorBlock(entry)
	fmt.Printf("error blocks: %v\n", len(errorBlocks))
	for _, b := range entry.ContainsBlock {
		if errorBlocks[b] {
			fmt.Printf("error block: %v %v\n", b.Function.Name, b.Id)
		}
	}

	totalPaths := 1
	for _, b := range entry.ContainsBlock {
		if b.LastInstr == nil {
			continue
		}
		if _, ok := (*b.LastInstr.SsaInstrPtr).(*ssa.If); ok {
			totalPaths *= 2
		}
	}

	for len(pathStack) > 0 {
		curState := pathStack[len(pathStack)-1]
		pathStack = pathStack[:len(pathStack)-1]
		if curState.visitedBlocks[edge{curState.prevBlock, curState.curBlock}] {
			continue
		}
		curState.visitedBlocks[edge{curState.prevBlock, curState.curBlock}] = true
		if curState.curBlock == nil || curState.curBlock.FirstInstr == nil {
			allPaths = append(allPaths, makePathCopy(curState.path))
			allPathsConds = append(allPathsConds, curState.conds)
			continue
		}
		curState.path = append(curState.path, curState.curBlock)
		curInstr := curState.curBlock.FirstInstr
		curState.curFunc = curState.curBlock.Function

		fmt.Printf("curBlock: %v %v, len pathStack: %v, len allPaths: %v, totalPaths: %v\n",
			curState.curFunc.Name, curState.curBlock.Id, len(pathStack), len(allPaths), totalPaths)
		for {
			if curInstr == nil {
				break
			}

			if curInstr.SsaInstrPtr == nil {
				fmt.Printf("ssa instruction for %v is nil\n", curInstr.Text)
				break
			}

			fmt.Printf("%v\n", curInstr.Text)

			switch (*curInstr.SsaInstrPtr).(type) {
			case ssa.CallInstruction:
				for _, call := range curInstr.InstrCalls {
					if pe.processFunc(call) {
						if _, ok := pe.callPaths[call]; !ok {
							pe.callPaths[call] = make([][]*PdgGraph.Block, 0)
							pe.callConds[call] = make([][]string, 0)
							callPaths, callConds := pe.FindPaths(progInfo, call)
							// trimedPaths, trimedConds := trimErrorPaths(call, callPaths, callConds)
							pe.callPaths[call] = callPaths
							pe.callConds[call] = callConds
						}
					}
				}

			}

			if curInstr == curState.curBlock.LastInstr || curInstr.InstrNext == nil {
				// fmt.Printf("End of block: %v %v\n", curState.curFunc.Name, curState.curBlock.Id)
				switch len(curState.curBlock.Successors) {
				case 0:
					curState.prevBlock = curState.curBlock
					curState.curBlock = nil
					pathStack = append(pathStack, curState)
				case 1:
					curState.prevBlock = curState.curBlock
					curState.curBlock = curState.curBlock.Successors[0]
					curState.conds = append(curState.conds, "-")
					pathStack = append(pathStack, curState)
				case 2:
					if curInstr.SSAType != "If" {
						fmt.Printf("SSAType is not If: %v\n", curInstr.SSAType)
					}
					falseState := pathState{
						curFunc:       curState.curFunc,
						curBlock:      curState.curBlock,
						prevBlock:     curState.prevBlock,
						path:          makePathCopy(curState.path),
						conds:         makeCondCopy(curState.conds),
						visitedBlocks: makeVisitedBlocksCopy(curState.visitedBlocks),
					}
					for _, succ := range curState.curBlock.Successors {
						if succ.Id == curInstr.TrueJump {
							if !errorBlocks[succ] {
								curState.prevBlock = curState.curBlock
								curState.curBlock = succ
								curState.conds = append(curState.conds, curInstr.Text)
								pathStack = append(pathStack, curState)
							}
						} else if succ.Id == curInstr.FalseJump {
							if !errorBlocks[succ] {
								falseState.prevBlock = falseState.curBlock
								falseState.curBlock = succ
								falseState.conds = append(falseState.conds, fmt.Sprintf("!(%v)", curInstr.Text))
								pathStack = append(pathStack, falseState)
							}
						}
					}
				default:
					fmt.Printf("More than 2 next blocks: %+v\n", *curState.curBlock)
				}
				break
			}
			curInstr = curInstr.InstrNext
		}
	}
	fmt.Printf("finished exploring function: %v\n", entry.Name)
	return
}

func (pe *PathExplorer) PrintExploreFuncs() {
	fmt.Printf("exploreFuncs: %v\n", len(pe.exploreFuncs))
	for f, b := range pe.exploreFuncs {
		fmt.Printf("%v: %v\n", f.Name, b)
	}
}

// processFunc returns true if the function should be explored
// heuristic:
// the function has to be in the package that we are processing
// only explore functions that are called by no more than two different callers
// and the callers are from the same package
// otherwise consider it a harnessing function
func (pe *PathExplorer) processFunc(f *PdgGraph.Function) bool {
	if b, ok := pe.exploreFuncs[f]; ok {
		return b
	}

	fmt.Printf("package name: %v, module name: %v\n", f.Package.FullName(), pe.moduleName)
	if !strings.Contains(f.Package.FullName(), pe.moduleName) {
		pe.exploreFuncs[f] = false
		return false
	}

	if len(f.Caller) > 2 {
		pe.exploreFuncs[f] = false
		return false
	}

	pkgMap := make(map[*PdgGraph.Package]bool)
	for _, info := range f.Caller {
		pkgMap[info.Package] = true
	}
	if len(pkgMap) > 1 {
		pe.exploreFuncs[f] = false
		return false
	}

	pe.exploreFuncs[f] = true
	return true

	// fmt.Printf("\n\nfunction: %v\n", f.Name)
	// for name, info := range f.Caller {
	// 	fmt.Printf("caller: %v %+v\n", name, *info)
	// }
	// return f.Name == "AssociateRanToE2THandlerImpl" || f.Name == "validateE2TAddressRANListData" ||
	// 	f.Name == "checkValidaE2TAddress"
	// return f.Name != "Warn" && f.Name != "Debug" && f.Name != "Info" && f.Name != "Error"
}

func makePathCopy(path []*PdgGraph.Block) []*PdgGraph.Block {
	res := make([]*PdgGraph.Block, len(path))
	for i, block := range path {
		res[i] = block
	}
	return res
}

func makeCondCopy(cond []string) []string {
	res := make([]string, len(cond))
	for i, c := range cond {
		res[i] = c
	}
	return res
}

func makeVisitedBlocksCopy(visitedBlocks map[edge]bool) map[edge]bool {
	res := make(map[edge]bool)
	for block, visited := range visitedBlocks {
		res[edge{block.from, block.to}] = visited
	}
	return res
}

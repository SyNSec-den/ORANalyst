package path_collection

import (
	"fmt"
	"go_fsmbuilder/PdgGraph"

	"golang.org/x/tools/go/ssa"
)

type TrackedVar struct {
	TrackedVars map[*PdgGraph.Variable]bool
	Instrs      []*PdgGraph.Instruction
}

func makeInstrCopy(orig *PdgGraph.Instruction) *PdgGraph.Instruction {
	curInstr := &PdgGraph.Instruction{
		AssignFrom:  make(map[string]*PdgGraph.Variable),
		AssignTo:    make(map[string]*PdgGraph.Variable),
		Block:       orig.Block,
		Text:        orig.Text,
		SsaInstrPtr: orig.SsaInstrPtr,
		SSAType:     orig.SSAType,
	}
	for i, assignFrom := range orig.AssignFrom {
		curInstr.AssignFrom[i] = assignFrom
	}
	for i, assignTo := range orig.AssignTo {
		curInstr.AssignTo[i] = assignTo
	}
	return curInstr
}

func compareTrackVars(old, new []TrackedVar) bool {
	if len(old) != len(new) {
		return false
	}
	for i, oldVar := range old {
		newVar := new[i]
		if len(oldVar.TrackedVars) != len(newVar.TrackedVars) {
			return false
		}
		for k, newVal := range newVar.TrackedVars {
			if oldVal, ok := oldVar.TrackedVars[k]; !ok || oldVal != newVal {
				return false
			}
		}
		if len(oldVar.Instrs) != len(newVar.Instrs) {
			return false
		}
	}

	return true
}

func makeTrackedVarsCopy(orig []TrackedVar) []TrackedVar {
	newTrackedVars := make([]TrackedVar, 0)
	for _, trackedVar := range orig {
		newTrackedVar := TrackedVar{}
		newTrackedVar.TrackedVars = make(map[*PdgGraph.Variable]bool)
		for k, v := range trackedVar.TrackedVars {
			newTrackedVar.TrackedVars[k] = v
		}
		newTrackedVar.Instrs = make([]*PdgGraph.Instruction, 0)
		for _, instr := range trackedVar.Instrs {
			newTrackedVar.Instrs = append(newTrackedVar.Instrs, instr)
		}
		newTrackedVars = append(newTrackedVars, newTrackedVar)
	}
	return newTrackedVars
}

// GetTrackedVars given a path, return all instructions tainted by the tracked variable
func (pe *PathExplorer) GetTrackedVars(instrs []*PdgGraph.Instruction, conds []string) []TrackedVar {
	var lastBlock *PdgGraph.Block
	var lastFunc *PdgGraph.Function
	oldTrackVars := make([]TrackedVar, 0)
	trackedVars := make([]TrackedVar, 0)
	i := 0
	firstIter := true
	iter := 0
	for {
		if !firstIter {
			break
			if compareTrackVars(oldTrackVars, trackedVars) {
				break
			}
			oldTrackVars = makeTrackedVarsCopy(trackedVars)
			lastBlock = nil
			lastFunc = nil
			for i, _ := range trackedVars {
				trackedVars[i].Instrs = make([]*PdgGraph.Instruction, 0)
			}
			i = 0
			iter++
		}
		for _, instr := range instrs {
			if lastBlock != instr.Block {
				fmt.Printf("entering basic block %v: %v\n", instr.Block.Function.Name, instr.Block.Id)
				lastBlock = instr.Block
				if lastFunc != lastBlock.Function {
					fmt.Printf("entering function %v\n", lastBlock.Function.Name)
					lastFunc = lastBlock.Function
				}
			}

			// identify initial variables to track
			if firstIter {
				switch ins := (*instr.SsaInstrPtr).(type) {
				case *ssa.Call:
					if ins.Call.Value != nil {
						fmt.Println(describeType(ins.Call.Value.Type()))
					}
					if ins.Call.Value != nil && pe.typeTracker.isTrackedType(ins.Call.Value.Type()) {
						varsMap := make(map[*PdgGraph.Variable]bool)
						for _, assign := range instr.AssignTo {
							varsMap[assign] = true
						}

						trackedVars = append(trackedVars, TrackedVar{
							TrackedVars: varsMap,
							Instrs:      []*PdgGraph.Instruction{instr},
						})
					} else {
						trackedVars = taintVar(instr, trackedVars)
					}
				case *ssa.FieldAddr:
					if pe.typeTracker.isTrackedType(ins.X.Type()) {
						if len(instr.AssignTo) != 1 {
							panic("field addr does not assign to one variable")
						}
						varsMap := make(map[*PdgGraph.Variable]bool)
						for _, assign := range instr.AssignTo {
							varsMap[assign] = true
						}

						trackedVars = append(trackedVars, TrackedVar{
							TrackedVars: varsMap,
							Instrs:      []*PdgGraph.Instruction{instr},
						})
					} else {
						trackedVars = taintVar(instr, trackedVars)
					}
				case *ssa.If:
					instrCopy := makeInstrCopy(instr)
					instrCopy.Text = conds[i]
					trackedVars = taintVar(instrCopy, trackedVars)
				default:
					trackedVars = taintVar(instr, trackedVars)
				}
			} else {
				switch (*instr.SsaInstrPtr).(type) {
				case *ssa.If:
					instrCopy := makeInstrCopy(instr)
					instrCopy.Text = conds[i]
					trackedVars = taintVar(instrCopy, trackedVars)
				default:
					trackedVars = taintVar(instr, trackedVars)
				}
			}

			if instr == instr.Block.LastInstr || instr.InstrNext == nil {
				if len(instr.Block.Successors) > 0 {
					if i < len(conds) {
						i++
					}
				}
			}
		}
		firstIter = false
	}
	return trackedVars
}

func taintVar(instr *PdgGraph.Instruction, trackedVars []TrackedVar) []TrackedVar {
	for idx := range trackedVars {
		trackedVar := &trackedVars[idx]
		tainted := false
		for _, assignFrom := range instr.AssignFrom {
			if !tainted && trackedVar.TrackedVars[assignFrom] {
				tainted = true
				trackedVar.Instrs = append(trackedVar.Instrs, instr)
				for _, assignTo := range instr.AssignTo {
					trackedVar.TrackedVars[assignTo] = true
				}
				for _, AssignFrom := range instr.AssignFrom {
					trackedVar.TrackedVars[AssignFrom] = true
				}
			}
		}
		if !tainted {
			for _, assignTo := range instr.AssignTo {
				if !tainted && trackedVar.TrackedVars[assignTo] {
					tainted = true
					trackedVar.Instrs = append(trackedVar.Instrs, instr)
					for _, assignTo := range instr.AssignTo {
						trackedVar.TrackedVars[assignTo] = true
					}
					for _, AssignFrom := range instr.AssignFrom {
						trackedVar.TrackedVars[AssignFrom] = true
					}
				}
			}
		}
	}

	return trackedVars
}

// // GetTrackedVars given a path, return all instructions tainted by the tracked variable
// func (pe *PathExplorer) GetTrackedVarsOld(instrs []*PdgGraph.Instruction, conds []string) []TrackedVar {
// 	var lastBlock *PdgGraph.Block
// 	var lastFunc *PdgGraph.Function
// 	oldTrackVars := make([]TrackedVar, 0)
// 	trackedVars := make([]TrackedVar, 0)
// 	i := 0
// 	iter := false
// 	for {
// 		if iter {
// 			if compareTrackVars(oldTrackVars, trackedVars) {
// 				break
// 			}
// 			oldTrackVars = trackedVars
// 			lastBlock = nil
// 			lastFunc = nil
// 			trackedVars = make([]TrackedVar, 0)
// 			i = 0
// 		} else {
// 			iter = true
// 		}
// 		for _, instr := range instrs {
// 			if lastBlock != instr.Block {
// 				fmt.Printf("entering basic block %v: %v\n", instr.Block.Function.Name, instr.Block.Id)
// 				lastBlock = instr.Block
// 				if lastFunc != lastBlock.Function {
// 					fmt.Printf("entering function %v\n", lastBlock.Function.Name)
// 					lastFunc = lastBlock.Function
// 				}
// 			}

// 			switch ins := (*instr.SsaInstrPtr).(type) {
// 			case *ssa.Call:
// 				if ins.Call.Value != nil && pe.typeTracker.isTrackedType(ins.Call.Value.Type()) {
// 					varsMap := make(map[*PdgGraph.Variable]bool)
// 					for _, assign := range instr.AssignTo {
// 						varsMap[assign] = true
// 					}

// 					trackedVars = append(trackedVars, TrackedVar{
// 						TrackedVars: varsMap,
// 						Instrs:      []*PdgGraph.Instruction{instr},
// 					})
// 				} else {
// 					for _, assignFrom := range instr.AssignFrom {
// 						for idx := range trackedVars {
// 							trackedVar := &trackedVars[idx]
// 							if trackedVar.TrackedVars[assignFrom] {
// 								trackedVar.Instrs = append(trackedVar.Instrs, instr)
// 								for _, assignTo := range instr.AssignTo {
// 									trackedVar.TrackedVars[assignTo] = true
// 								}
// 							}
// 						}
// 					}
// 				}
// 			case *ssa.FieldAddr:
// 				if pe.typeTracker.isTrackedType(ins.X.Type()) {
// 					if len(instr.AssignTo) != 1 {
// 						panic("field addr does not assign to one variable")
// 					}
// 					varsMap := make(map[*PdgGraph.Variable]bool)
// 					for _, assign := range instr.AssignTo {
// 						varsMap[assign] = true
// 					}

// 					trackedVars = append(trackedVars, TrackedVar{
// 						TrackedVars: varsMap,
// 						Instrs:      []*PdgGraph.Instruction{instr},
// 					})
// 				} else {
// 					fmt.Printf("untracked field addr: %v\n", ins.X.Type())
// 				}
// 			case *ssa.If:
// 				for _, assignFrom := range instr.AssignFrom {
// 					for idx := range trackedVars {
// 						trackedVar := &trackedVars[idx]
// 						if trackedVar.TrackedVars[assignFrom] {
// 							instrCopy := makeInstrCopy(instr)
// 							instrCopy.Text = conds[i]
// 							trackedVar.Instrs = append(trackedVar.Instrs, instrCopy)
// 							for _, assignTo := range instr.AssignTo {
// 								trackedVar.TrackedVars[assignTo] = true
// 							}
// 						}
// 					}
// 				}
// 			default:
// 				for _, assignFrom := range instr.AssignFrom {
// 					for idx := range trackedVars {
// 						trackedVar := &trackedVars[idx]
// 						if trackedVar.TrackedVars[assignFrom] {
// 							trackedVar.Instrs = append(trackedVar.Instrs, instr)
// 							for _, assignTo := range instr.AssignTo {
// 								trackedVar.TrackedVars[assignTo] = true
// 							}
// 						}
// 					}
// 				}

// 			}

// 			if instr == instr.Block.LastInstr || instr.InstrNext == nil {
// 				if len(instr.Block.Successors) > 0 {
// 					if i < len(conds) {
// 						i++
// 					}
// 				}
// 			}
// 		}
// 	}
// 	return trackedVars
// }

func DetermineConstraints(trackedVars []TrackedVar) []string {
	for _, trackedVar := range trackedVars {
		fmt.Printf("tracked var: %v\n", trackedVar)
	}
	return nil
}

package path_collection

import (
	"fmt"
	"go_fsmbuilder/PdgGraph"

	"golang.org/x/tools/go/ssa"
)

// EnumeratePaths enumerate all paths from the entry point to the exit point.
// Each path is represented as a list of instructions from different blocks in different functions.
func (pe *PathExplorer) EnumeratePaths(paths [][]*PdgGraph.Block,
	conds [][]string, exit *PdgGraph.Function) ([]string, [][]*PdgGraph.Instruction, [][]string) {
	tmpPaths, tmpInstrs, tmpConds, tmpHasExits := pe.enumeratePaths(paths, conds, exit)
	resPath := make([]string, 0)
	resInstr := make([][]*PdgGraph.Instruction, 0)
	resConds := make([][]string, 0)
	for i, tmpPath := range tmpPaths {
		if tmpHasExits[i] {
			resPath = append(resPath, tmpPath)
			resInstr = append(resInstr, tmpInstrs[i])
			resConds = append(resConds, tmpConds[i])
		}
	}
	return resPath, resInstr, resConds
}

func (pe *PathExplorer) enumeratePaths(paths [][]*PdgGraph.Block,
	conds [][]string, exit *PdgGraph.Function) ([]string, [][]*PdgGraph.Instruction, [][]string, []bool) {
	res := make([]string, 0)
	trackedRes := make([][]*PdgGraph.Instruction, 0)
	condRes := make([][]string, 0)
	hasExit := make([]bool, 0)
	for i, path := range paths {
		path, trackedVarPath, conds, e := pe.enumeratePath(path, conds[i], exit)
		res = append(res, path...)
		trackedRes = append(trackedRes, trackedVarPath...)
		condRes = append(condRes, conds...)
		hasExit = append(hasExit, e...)
	}
	return res, trackedRes, condRes, hasExit
}

func appendText(res []string, text string) []string {
	newRes := make([]string, 0)
	for _, r := range res {
		r += text
		newRes = append(newRes, r)
	}
	return newRes
}

func addInstr(instrs [][]*PdgGraph.Instruction, instr []*PdgGraph.Instruction) [][]*PdgGraph.Instruction {
	if len(instr) == 0 {
		return instrs
	}
	if len(instrs) == 0 {
		return [][]*PdgGraph.Instruction{instr}
	}
	newInstrs := make([][]*PdgGraph.Instruction, 0)
	for _, i := range instrs {
		newInstrs = append(newInstrs, append(i, instr...))
	}
	return newInstrs
}

func addCond(conds [][]string, cond string) [][]string {
	if len(conds) == 0 {
		return [][]string{[]string{cond}}
	}
	newConds := make([][]string, 0)
	for _, c := range conds {
		newConds = append(newConds, append(c, cond))
	}
	return newConds
}

// return val: path text, path instrs, conds for each path
func (pe *PathExplorer) enumeratePath(paths []*PdgGraph.Block,
	conds []string, exit *PdgGraph.Function) ([]string, [][]*PdgGraph.Instruction, [][]string, []bool) {
	res := []string{""}
	insRes := make([][]*PdgGraph.Instruction, 0)
	condRes := make([][]string, 0)
	hasExits := []bool{false}

	i := 0

	for _, block := range paths {
		res = appendText(res, fmt.Sprintf("entering basic block %v: %v\n", block.Function.Name, block.Id))

		curInstr := block.FirstInstr
		for {
			if curInstr == nil {
				break
			}
			res = appendText(res, fmt.Sprintf("\t%v\n", curInstr.Text))
			insRes = addInstr(insRes, []*PdgGraph.Instruction{curInstr})

			switch (*curInstr.SsaInstrPtr).(type) {
			case ssa.CallInstruction:
				for _, call := range curInstr.InstrCalls {
					if call == exit {
						res = appendText(res, fmt.Sprintf("end of basic block %v: %v\n", block.Function.Name, block.Id))
						res = appendText(res, fmt.Sprintf("found exit: %v\n", exit.Name))
						for i := range hasExits {
							hasExits[i] = true
						}
						return res, insRes, condRes, hasExits
					}
					if pe.processFunc(call) {
						funcPaths, funcInstrs, funcConds, funcExits := pe.enumeratePaths(pe.callPaths[call], pe.callConds[call], exit) // TODO: print tracked vars
						newRes := make([]string, 0)
						for _, r := range res {
							for _, p := range funcPaths {
								newRes = append(newRes, r+p)
							}
						}
						res = newRes

						newInstrs := make([][]*PdgGraph.Instruction, 0)
						for _, i := range insRes {
							for _, p := range funcInstrs {
								newInstrs = append(newInstrs, append(i, p...))
							}
						}
						insRes = newInstrs

						newConds := make([][]string, 0)
						for _, c := range condRes {
							for _, p := range funcConds {
								newConds = append(newConds, append(c, p...))
							}
						}
						condRes = newConds
						if len(condRes) == 0 {
							condRes = funcConds
						}

						newHasExits := make([]bool, 0)
						for _, e := range hasExits {
							for _, p := range funcExits {
								newHasExits = append(newHasExits, e || p)
							}
						}
						hasExits = newHasExits
						exitCount := 0
						for _, b := range hasExits {
							if b {
								exitCount++
							}
						}
						if exitCount == len(hasExits) {
							return res, insRes, condRes, hasExits
						}
					}
				}
			}

			if curInstr == block.LastInstr || curInstr.InstrNext == nil {
				cond := ""
				if len(block.Successors) > 0 {
					if i < len(conds) {
						cond = conds[i]
						i++
					}
				}
				res = appendText(res, fmt.Sprintf("end of basic block %v: %v\n", block.Function.Name, block.Id))
				if cond != "" {
					res = appendText(res, fmt.Sprintf("condition: %v\n", cond))
					condRes = addCond(condRes, cond)
				}
			}

			curInstr = curInstr.InstrNext
		}
	}

	return res, insRes, condRes, hasExits
}

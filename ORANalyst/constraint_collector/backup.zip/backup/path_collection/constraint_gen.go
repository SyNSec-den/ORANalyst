package path_collection

import (
	"fmt"
	"go/types"
	"go_fsmbuilder/PdgGraph"
	"strings"

	"golang.org/x/tools/go/ssa"
)

type Constraint struct {
	TrackedVar            TrackedVar
	AssignStatement       *PdgGraph.Instruction
	AssignStatementString string
	IfStatement           *PdgGraph.Instruction
	Condition             string
	ConditionAssign       *PdgGraph.Instruction
	ConditionAssignString string
}

func (pe *PathExplorer) GenConstraint(trackedVar TrackedVar) []Constraint {
	res := make([]Constraint, 0)
	instrs := trackedVar.Instrs
	assignInstr := instrs[0]
	var assignStr string
	switch ins := (*assignInstr.SsaInstrPtr).(type) {
	case *ssa.Call:
		if ins.Call.Value != nil && pe.typeTracker.isTrackedType(ins.Call.Value.Type()) {
			t := ins.Call.Value.Type()
			if sigT, ok := t.(*types.Signature); ok {
				t = sigT.Recv().Type()
			}
			// fmt.Printf("variable: %v\n", t)
			// fmt.Printf("generating constraint for input function: %v.%v\n", t, ins.Call.Value.Name())
			assignStr = fmt.Sprintf("%v.%v", t, ins.Call.Value.Name())
		}
	case *ssa.FieldAddr:
		if pe.typeTracker.isTrackedType(ins.X.Type()) {
			// fmt.Printf("variable: %v\n", ins.X.Type())
			_, fieldName, err := getField(ins.X.Type(), ins.Field)
			if err != nil {
				panic(err)
			}
			// fmt.Printf("generating constraint for input field: %v.%v\n", ins.X.Type(), fieldName)
			assignStr = fmt.Sprintf("%v.%v", ins.X.Type(), fieldName)
		}
	}

	for i, instr := range instrs {
		switch ssaInstr := (*instr.SsaInstrPtr).(type) {
		case *ssa.If:
			fmt.Printf("the condition is: %v\n", instr.Text)
			if strings.Contains(instr.Text, "!") {
			}
			var assignFrom *PdgGraph.Variable
			for _, af := range instr.AssignFrom {
				assignFrom = af
			}
			if len(instr.AssignFrom) != 1 {
				panic(fmt.Sprintf("if instruction does not assign from one variable: %v, len assign from: %v\n",
					instr.Text, len(instr.AssignFrom)))
			}

			// do a back data-flow to find the possible assignment for the condition
			tainted := make(map[*PdgGraph.Variable]bool)
			tainted[assignFrom] = true
			var conditionAssign *PdgGraph.Instruction
			var conditionAssignStr string
			foundConditionAssign := false
			for j := i - 1; j >= 0; j-- {
				if foundConditionAssign {
					break
				}
				prevInstr := instrs[j]
				for _, assignTo := range prevInstr.AssignTo {
					if tainted[assignTo] {
						for _, assignFrom := range prevInstr.AssignFrom {
							tainted[assignFrom] = true
						}
						switch (*prevInstr.SsaInstrPtr).(type) {
						case *ssa.Call, *ssa.BinOp:
							conditionAssign = prevInstr
							conditionAssignStr = prevInstr.Text
							res = append(res, Constraint{
								TrackedVar:            trackedVar,
								AssignStatement:       assignInstr,
								AssignStatementString: assignStr,
								IfStatement:           instr,
								Condition:             instr.Text,
								ConditionAssign:       conditionAssign,
								ConditionAssignString: conditionAssignStr,
							})
							foundConditionAssign = true
						}
					}
				}
			}
		case *ssa.Call:
			if builtin, ok := ssaInstr.Common().Value.(*ssa.Builtin); ok {
				if builtin.Name() == "len" {
					// a for loop iterating the slice
					return make([]Constraint, 0)
				}
			}
		}
	}
	return res
}

func getField(t types.Type, i int) (types.Type, string, error) {
	switch t := t.(type) {
	case *types.Basic:
		return t, "", fmt.Errorf("cannot get field of basic type: %v", t)
	case *types.Array:
		return t.Elem(), "", fmt.Errorf("cannot get field of array type: %v", t)
	case *types.Slice:
		return t.Elem(), "", fmt.Errorf("cannot get field of slice type: %v", t)
	case *types.Struct:
		return t.Field(i).Type(), t.Field(i).Name(), nil
	case *types.Pointer:
		return getField(t.Elem(), i)
	case *types.Interface:
		return t, "", fmt.Errorf("cannot get field of interface type: %v", t)
	case *types.Map:
		return t.Elem(), "", fmt.Errorf("cannot get field of map type: %v", t)
	case *types.Chan:
		return t.Elem(), "", fmt.Errorf("cannot get field of channel type: %v", t)
	case *types.Named:
		underlyingType, fieldName, err := getField(t.Underlying(), i)
		if _, ok := t.Underlying().(*types.Struct); ok {
			fieldName = t.Obj().Name() + "." + fieldName // Prepend struct name
		}
		return underlyingType, fieldName, err
	case *types.Tuple:
		return t.At(i).Type(), "", nil
	case *types.Signature:
		return t, "", fmt.Errorf("cannot get field of function type: %v", t)
	case *types.Union:
		return t, "", fmt.Errorf("cannot get field of union type: %v", t)
	default:
		return t, "", fmt.Errorf("unknown type: %v", t)
	}
}

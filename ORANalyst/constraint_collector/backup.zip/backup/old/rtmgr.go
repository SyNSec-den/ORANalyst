package module_constraint

import (
	"flag"
	"fmt"
	"go/types"
	"go_fsmbuilder/PdgGraph"
	"go_fsmbuilder/condition_collection"
	"go_fsmbuilder/path_collection"
	"strings"

	"golang.org/x/tools/go/packages"
)

func RtMgr_old() {
	progInfoGraph := PdgGraph.NewProgramInfo()
	fmt.Printf("------------- processing path constraint -------------\n")
	for i := 0; i < flag.NArg(); i++ {
		path := flag.Arg(i)
		if path[len(path)-1] == []byte("/")[0] {
			path = path[0 : len(path)-1]
		}
		pathSplit := strings.Split(path, "/")
		module := pathSplit[len(pathSplit)-1]
		fmt.Printf("------------- processing %v -------------\n", module)
		parser := PdgGraph.NewProgParser(module)
		progInfoGraph = parser.ProcessPackage(path, progInfoGraph)
		var entry *PdgGraph.Function
		var exit *PdgGraph.Function
		var inputType types.Type
		var inputPackage packages.Package
		for name, pkg := range progInfoGraph.ContainsPkg {
			if inputType == nil {
				inputType, _ = condition_collection.LookUpTypeFromPackage(pkg.PackagePtr, "RanE2tMap")
				inputPackage = *pkg.PackagePtr
			}
			if name == "routing-manager/pkg/nbi" {
				// if name == "github.com/onosproject/onos-e2t/pkg/southbound/e2ap/server" {
				for funcName, funcInfo := range pkg.ContainsFunction {
					// if funcName == "RICIndication" {
					if funcName == "AssociateRanToE2THandlerImpl" {
						entry = funcInfo
					}
				}
			}
			if name == "routing-manager/pkg/nbi" {
				// if name == "github.com/onosproject/onos-e2t/pkg/southbound/e2ap/stream" {
				for funcName, funcInfo := range pkg.ContainsFunction {
					// if funcName == "In" {
					if funcName == "sendRoutesToAll" {
						exit = funcInfo
					}
				}
			}
		}
		fmt.Printf("input type: %v\n", inputType)
		pe := path_collection.NewPathExplorer("routing-manager", inputType, nil, inputPackage)
		cc := condition_collection.NewConditionCollector("routing-manager", []types.Type{inputType}, nil, inputPackage)
		cc.CollectPathConditions(entry, exit)
		return
		allPaths, allConds := pe.FindPaths(progInfoGraph, entry)
		pe.PrintExploreFuncs()
		fmt.Printf("\n\n\n\n------------- paths -------------\n")
		pathText, pathInstr, pathCond := pe.EnumeratePaths(allPaths, allConds, exit)
		fmt.Printf("len of path text: %v, len of path instr: %v, len of path cond: %v\n",
			len(pathText), len(pathInstr), len(pathCond))

		for i, p := range pathInstr {
			trackedVar := pe.GetTrackedVars(p, pathCond[i])
			fmt.Printf("-------------  path %v -------------\n ", i)
			fmt.Printf("%v\n", pathText[i])
			for ti, t := range trackedVar {
				constraints := pe.GenConstraint(t)
				// for trackedV, _ := range t.TrackedVars {
				// 	fmt.Printf("tracked vars: %v\n", trackedV.Name)
				// }
				if len(constraints) > 0 {
					fmt.Printf("-------------  tracked input %v-%v  -------------\n ", i, ti)
					for _, instr := range t.Instrs {
						fmt.Printf("\t%v\n", instr.Text)
					}
				}

				for ci, c := range constraints {
					fmt.Printf("------------- conditions %v-%v-%v -------------\n", i, ti, ci)
					fmt.Printf("\t%v\n", c.AssignStatement.Text)
					fmt.Printf("\t%v\n", c.AssignStatementString)
					fmt.Printf("\t%v\n", c.ConditionAssignString)
					fmt.Printf("\t%v\n", c.Condition)
				}

			}
			fmt.Printf("------------- end of path %v -------------\n\n\n", i)
		}
	}
}
